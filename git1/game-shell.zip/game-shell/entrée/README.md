Il y a un bug dans cette pièce !
Supprime le grâce à cette commande.

rm bug

Une fois que tu auras supprimé le bug tu pourras activé le levier avec la commande suivante :

bash levier.sh

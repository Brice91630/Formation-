Bienvenue jeune aventurier !
Des trésors sont déssiminés dans les différentes pièces de ce château fort.

Il y a 3 trésors à récupérer.

Voici la première commande qui te permettra de passer la porte du château.

cd entrée
# game-shell-bash

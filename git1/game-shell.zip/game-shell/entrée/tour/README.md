Des morceaux de bois jonche le sol, au-dessus de toi tu remarque un accès mais tu ne peux pas sauter.
Créer une échelle avec la commande suivante :

touch echelle